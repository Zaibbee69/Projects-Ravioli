import "../styles/components/hero.scss"
import { Link } from "react-router-dom"
import HeroCard from "./HeroCard"
import ServiceCard from "./ServiceCard";
import { faShieldHalved, faHandHoldingHeart, faStopwatch, faCircleNotch, faFileSignature, faIdCard, faShieldAlt, faCarBurst  } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import hero1 from "../assets/hero1.webp"
import hero2 from "../assets/hero2.webp"
import hero3 from "../assets/hero3.webp"



function Hero() {

    const images = [
        hero1,
        hero2,
        hero3,
    ];

    const [currentImage, setCurrentImage] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
        setCurrentImage(prev => (prev + 1) % images.length);
        }, 5000); // every 5 seconds

        return () => clearInterval(interval); // cleanup
    }, [images.length]);

    const services = 
    [
        {
        icon: faShieldAlt,
        heading: "Car Insurance",
        text: "Full and third-party insurance plans with flexible pricing and fast claim processing."
        },
        {
        icon: faFileSignature,
        heading: "Vehicle Registration",
        text: "Get your new or renewed vehicle registered quickly — with all legal formalities handled."
        },
        {
        icon: faIdCard,
        heading: "Policy Extensions",
        text: "Easily extend your TPL or full coverage policy with minimal paperwork and maximum support."
        },
        {
        icon: faCarBurst,
        heading: "Corporate Insurance",
        text: "Custom fleet insurance for companies — bulk discounts, multi-car support, priority service."
        }
    ];


    const cardData = [
        {
            icon: faShieldHalved,
            heading: "Comprehensive Protection",
            text: "We offer full and third-party insurance options that safeguard your vehicle and finances — so you're never left vulnerable in uncertain moments."
        },
        {
            icon: faHandHoldingHeart,
            heading: "Trusted Expertise",
            text: "Backed by years of industry experience, our insurance professionals provide clear guidance and tailor-made coverage to meet your exact needs."
        },
        {
            icon: faStopwatch,
            heading: "Fast Efficient Service",
            text: "From instant quotes to fast claim settlements, we make the process smooth, stress-free, and efficient — because your time matters."
        }
    ]

    const cardElements = cardData.map((card, index) => {
        return <HeroCard key={index} icon={card.icon} heading={card.heading} text={card.text} />
    })

    const serviceCardElements = services.map((service, index) => {
        return <ServiceCard key={index} icon={service.icon} heading={service.heading} text={service.text} />
    })
    
  return (
    <>
        <section className="hero" style={{
        backgroundImage: `linear-gradient(to top, black, rgba(255, 255, 255, 0)), url(${images[currentImage]})`
      }}>
            <div className="hero-content">
                <FontAwesomeIcon className="fCircle" icon={faCircleNotch} spin />
                <motion.div
                    className="hero-content"
                    initial={{ opacity: 0, y: 40 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                >
                    <h1>Reliable <span>Car Insurance</span> & <span className="stylerr">Registration</span> in UAE</h1>
                    <p>FARAS helps you get TPL, Full Insurance, and Car Services quickly and hassle-free.</p>

                    <div className="hero-buttons">
                        <Link to="/quote" className="hero-btn primary">Get a Quote</Link>
                        <Link to="/services" className="hero-btn secondary">Explore Services</Link>
                    </div>
                </motion.div>
            </div>
        </section>

        <section className="hero-card-ctn">
            {cardElements}
        </section>

        <section className="services-card-ctn">
            <h1>Our Services</h1>
            <div>
                {serviceCardElements}
            </div>
        </section>
    </>
  )
}

export default Hero
