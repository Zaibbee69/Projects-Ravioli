import { Link } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlassDollar } from "@fortawesome/free-solid-svg-icons";
import logoImage from "../assets/logo.webp";
import altLogoImage from "../assets/alt-logo.webp"
import "../styles/components/navbar.scss";

function Navbar() {
    const [isScrolled, setIsScrolled] = useState(false);
    const [menuOpen, setMenuOpen] = useState(false);

    const navRef = useRef(null);

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };

        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    return (
        <nav ref={navRef} className={isScrolled ? "fixed-nav" : ""}>

                <div
                    className={`burger ${isScrolled ? "fixed-nav" : ""}`}
                    onClick={() => setMenuOpen(!menuOpen)}
                    aria-label="Toggle navigation menu"
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => { if (e.key === 'Enter') setMenuOpen(!menuOpen); }}
                >
                <div className="line"></div>
                <div className="line"></div>
                <div className="line"></div>
            </div>

            <Link to="/" className="main-logo" style={{
                textDecoration: "none"
            }}>
                <img src={!isScrolled ? logoImage : altLogoImage} alt="Faras Car Insurance logo" />
                <h1 id="company-name" className={isScrolled ? "fixed-nav" : ""}>Faras Car Insurance & Registration Services</h1>
            </Link>


            <div className={`nav-items ${menuOpen ? "open" : ""} ${isScrolled ? "fixed-nav" : ""}`}>
                <div className="nav-item">
                    <Link to="/" className={`nav-element ${isScrolled ? "fixed-nav" : ""}`}>Home</Link>
                </div>
                <div className="nav-item">
                    <Link to="/services" className={`nav-element ${isScrolled ? "fixed-nav" : ""}`}>Services</Link>
                </div>
                <div className="nav-item">
                    <Link to="/contact" className={`nav-element ${isScrolled ? "fixed-nav" : ""}`}>Contact</Link>
                </div>
                <div className="nav-item">
                    <Link to="/about" className={`nav-element ${isScrolled ? "fixed-nav" : ""}`}>About</Link>
                </div>
                { menuOpen && 
                    <div className="nav-item">
                        <Link to="/quote" className={`nav-element ${isScrolled ? "fixed-nav" : ""}`}>Get a Quote</Link>
                    </div>
                }
            </div>

            <div className={`nav-end ${isScrolled ? "fixed-nav" : ""}`}>
                <Link to="/quote" className="nav-end-element">
                    <FontAwesomeIcon icon={faMagnifyingGlassDollar} /> Get a Quote
                </Link>
            </div>
        </nav>
    );
}

export default Navbar;
