import "../styles/pages/contact.scss"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faEnvelope, faPhone, faLocationDot } from "@fortawesome/free-solid-svg-icons"
import { faWhatsapp } from "@fortawesome/free-brands-svg-icons"
import { motion } from "framer-motion"
import { Helmet } from "react-helmet-async"

function ContactPage() {
  return (
    <section className="contact">
      <Helmet>
        <title>Contact Us | FARAS Car Insurance & Registration UAE</title>
        <meta
          name="description"
          content="Reach FARAS Car Registration & Insurance services at our offices in Ajman. Contact us via WhatsApp, phone, or visit in person."
        />
        <link rel="canonical" href="https://www.farascar.com/contact" />
      </Helmet>

      <div className="contact-title">
        <motion.div
          className="hero-content"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <h1>Get in Touch</h1>
          <p>Reach out to us via phone, email, or visit us in Dubai</p>
          <h2>Our Offices Are At</h2>
        </motion.div>
      </div>

      <div className="offices-ctn">
        {/* HEAD OFFICE */}
        <div className="office">
          <h1>Head Office</h1>
          <div className="contact-info-box">
            <div className="contact-detail">
              <FontAwesomeIcon icon={faPhone} />
              <span>+971 50 674 6572</span>
            </div>
            <div className="contact-detail">
              <FontAwesomeIcon icon={faWhatsapp} />
              <span>+971 50 671 4578</span>
            </div>
            <div className="contact-detail">
              <FontAwesomeIcon icon={faEnvelope} />
              <span>farascarreg@gmail.com</span>
            </div>
            <div className="contact-detail">
              <FontAwesomeIcon icon={faLocationDot} />
              <span><strong>Location</strong> Ajman, Jurf Industrial Area 3, Near Speed Vehicle Passing Center, UAE</span>
            </div>
          </div>
          <div className="map-box">
            <iframe
              title="Faras Head Office"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3603.582972122447!2d55.549686900000005!3d25.418766399999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ef5f700245c69f1%3A0x3ea28e53ed007c6d!2sFARAS%20CAR%20INSURANCE%20REGISTRATION%20and%20EXTENSION%20SERVICE!5e0!3m2!1sen!2s!4v1752675039694!5m2!1sen!2s"              width="100%"
              height="300"
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>

        {/* BRANCH 1 */}
        <div className="office">
          <h1>Branch 1</h1>
          <div className="contact-info-box">
            <div className="contact-detail">
              <FontAwesomeIcon icon={faPhone} />
              <span>+971 50 141 0826</span>
            </div>
            <div className="contact-detail">
              <FontAwesomeIcon icon={faWhatsapp} />
              <span>+971 50 233 1693</span>
            </div>
            <div className="contact-detail">
              <FontAwesomeIcon icon={faEnvelope} />
              <span>farascarreg204@gmail.com</span>
            </div>
            <div className="contact-detail">
              <FontAwesomeIcon icon={faLocationDot} />
              <span><strong>Location</strong> Ajman, Hamidya 1, Behind Traffic Dept, Fast Vehicle Passing Center, UAE</span>
            </div>
          </div>
          <div className="map-box">
            <iframe
              title="Faras Branch Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3603.818854340228!2d55.5120995!3d25.410873499999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ef5f77ae422860b%3A0x4d1e4e79fd18ef9e!2sFARAS%20CAR%20INSURANCE%20REGISTRATION%20AND%20EXTENSION%20SERVICES%20BR.1!5e0!3m2!1sen!2s!4v1752674955888!5m2!1sen!2s"              width="100%"
              height="300"
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  )
}

export default ContactPage
