import "../styles/components/marquee.scss"

function ScrollMarquee(props)
{
    const scrollElements = props.marquee.map((marq, index) => (
        <span key={index}>{marq}</span>
    ))
    return(
        <>
            <div className="company-marquee">
                <div className="marquee-track">
                    
                    {scrollElements}

                    {/* repeat once more for seamless loop */}
                    {scrollElements}
                </div>
            </div>

        </>
    )
}

export default ScrollMarquee