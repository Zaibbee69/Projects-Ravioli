import "../styles/components/testimonials.scss"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faQuoteLeft } from "@fortawesome/free-solid-svg-icons"

const testimonials = [
  {
    name: "Ali R.",
    quote: "Faras handled my car insurance renewal in under 10 minutes — professional and fast!",
  },
  {
    name: "Sara M.",
    quote: "They helped me register my company fleet with ease. Highly recommended!",
  },
  {
    name: "Ahmed Z.",
    quote: "The process was smooth, and their customer support is excellent.",
  }
]

function TestimonialsSection() {
  return (
    <section className="testimonials-section">
      <h2>What Our Clients Say</h2>
      <div className="testimonial-grid">
        {testimonials.map((t, i) => (
          <div className="testimonial-card" key={i} data-aos="fade-up">
            <FontAwesomeIcon icon={faQuoteLeft} className="quote-icon" />
            <p>"{t.quote}"</p>
            <h4>- {t.name}</h4>
          </div>
        ))}
      </div>
    </section>
  )
}

export default TestimonialsSection
