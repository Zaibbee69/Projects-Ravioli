import { Link } from "react-router-dom"
import "../styles/components/plug.scss"

export default function PlugIn()
{
    return(
        <div className="plug-in">
            <div><Link to="/contact" className="hero-btn primary">Contact Us</Link></div>
            <div> <Link to="/services" className="hero-btn primary">Check Our Services</Link></div>
        </div>
    )
}