import "../styles/pages/about.scss";
// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link } from "react-router-dom";
import AOS from "aos";
import { useEffect } from "react";

function AboutBody()
{
    useEffect(() => {
            AOS.init({ duration: 1000 });
        }, []);

    return(
        <section className="about-page">

            <div className="about-hero">
                <motion.div
                            initial={{ opacity: 0, y: 40 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.8, ease: "easeOut" }}>
                    <h1>About Faras <span>Services</span></h1>
                    <p>Your trusted partner in car insurance & registration across the UAE.</p>
                </motion.div>
            </div>

            <div className="about-story">
                <h2><FontAwesomeIcon icon={faStar} /> Our Story <FontAwesomeIcon icon={faStar} /></h2>
                <p>
                We have been helping both individuals and companies 
                navigate car insurance, registration, and renewal services across the UAE with 
                transparency, speed, and trust.
                </p>
            </div>

            <div className="about-vision-mission">
                <div className="vision">
                <h3>Our Vision</h3>
                <p>To become the UAE’s most reliable platform for end-to-end car care services.</p>
                </div>
                <div className="mission">
                <h3>Our Mission</h3>
                <p>
                    Empower clients with quick, hassle-free solutions for car insurance, registration, 
                    and documentation — always at competitive rates.
                </p>
                <FontAwesomeIcon bounce icon={faStar} className="float-star"/>
                </div>
            </div>

            <div className="about-core" data-aos="fade-in">
                <div className="about-values">
                    <h3>Our Core Values</h3>
                    <ul>
                    <li><strong>Integrity:</strong> We build trust through honesty and transparency.</li>
                    <li><strong>Customer Focus:</strong> Your satisfaction is our top priority.</li>
                    <li><strong>Efficiency:</strong> We simplify complex processes and save your time.</li>
                    <li><strong>Innovation:</strong> We embrace technology to improve your experience.</li>
                    </ul>
                </div>

                {/* Section 3: Our Journey */}
                <div className="about-journey">
                    <h3>Our Journey</h3>
                    <p>
                    FARAS began with a simple idea: to make vehicle-related services faster, easier, and more accessible.
                    Today, we serve thousands of happy clients across the UAE — from individuals renewing their car insurance
                    to companies managing entire fleets.
                    </p>
                    <p>
                    With a strong network of partners and a customer-first mindset, we continue to grow while staying true 
                    to our roots of reliability, service, and trust.
                    </p>
                </div>

                {/* Section 4: Why People Trust FARAS */}
                <div className="about-trust">
                    <h3>Why People Trust FARAS</h3>
                    <ul>
                    <li>✅ Fast renewals and hassle-free registrations</li>
                    <li>✅ Competitive insurance rates from top providers</li>
                    <li>✅ Multilingual customer support</li>
                    <li>✅ 100% paperless digital experience</li>
                    <li>✅ Real-time WhatsApp and phone support</li>
                    </ul>
                </div>

                {/* Section 5: Call to Action */}
                <div className="about-cta">
                    <h3>Want a Seamless Car Service Experience?</h3>
                    <p>Join the thousands of satisfied customers who trust FARAS. Whether it's your first registration or tenth insurance renewal — we're with you every mile.</p>
                    <Link to="/quote" className="gold-button">Get a Free Quote</Link>
                </div>
            </div>

            
        </section>
    )
}

export default AboutBody