import "../styles/components/serviceHierarchy.scss"

function ServiceHierarchy() {
  return (
    <section className="service-hierarchy">
      <div className="node parent">Car Services</div>
      <div className="connector-line vertical"></div>

      <div className="children">
        <div className="connector-line horizontal"></div>
        <div className="node child">Car Insurance Services</div>
        <div className="node child">Car Registration Services</div>
        <div className="node child">Car Extension Services</div>
        <div className="node child">Home Services</div>
      </div>
    </section>
  )
}

export default ServiceHierarchy
