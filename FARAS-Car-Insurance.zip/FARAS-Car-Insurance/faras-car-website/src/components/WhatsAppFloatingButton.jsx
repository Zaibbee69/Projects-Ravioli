import { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faWhatsapp } from "@fortawesome/free-brands-svg-icons";
import "../styles/components/whatsapp.scss"

export default function WhatsAppFloatingButton() {
  const [showOptions, setShowOptions] = useState(false);

  return (
    <div className="whatsapp-float-container">
      <button
        className="whatsapp-button"
        onClick={() => setShowOptions((prev) => !prev)}
      >
        <FontAwesomeIcon icon={faWhatsapp} size="2x" color="white" />
      </button>

      {showOptions && (
        <div className="whatsapp-options">
          <a
            href="https://wa.me/971502331693?text=Hello%2C%20I%20would%20like%20to%20get%20a%20quote."
            target="_blank"
            rel="noopener noreferrer"
          >
            Contact 1
          </a>
          <a
            href="https://wa.me/971501410826?text=Hi%2C%20I%20need%20assistance%20with%20vehicle%20registration."
            target="_blank"
            rel="noopener noreferrer"
          >
            Contact 2
          </a>
        </div>
      )}
    </div>
  );
}
