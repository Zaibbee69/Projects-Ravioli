import { faCar, faMotorcycle, faTruckPickup, faBus, faTruck, faWater, faTrafficLight, faRegistered, faSortNumericAsc, 
  faMoneyBillTransfer, faDriversLicense, faBalanceScale, faRemove, faRubleSign, faRedo, faTeletype, faMoneyBill,
  faCircleUser, faTowerCell} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "../styles/pages/services.scss"
import ServiceHierarchy from "./ServiceHierarchy";
// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion";
import car from "../assets/car.webp"

export default function ServicesBody() {

  return (
    
    <div className="services-page">

        <div className="services-hero">
            <motion.div className="hero-content"
                        initial={{ opacity: 0, y: 40 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, ease: "easeOut" }}>
                <h1>Our <span>Services</span></h1>
                <p>We offer comprehensive solutions for Car insurance, Car registration, Car fines, Home services and more!</p>

            </motion.div>
        </div>


      <ServiceHierarchy />

      <section className="insurance-types" style={{
        backgroundImage: `linear-gradient(to top, black, rgba(255, 255, 255, 0)), url(${car})`
      }}>
        <div className="flexer"><h2 className="insurance-header">Car Insurance Services Types</h2></div>
        <div className="insurance-grid">
          <div><FontAwesomeIcon icon={faCar} /> Car</div>
          <div><FontAwesomeIcon icon={faMotorcycle} /> Motorcycle</div>
          <div><FontAwesomeIcon icon={faTruckPickup} /> Pickup</div>
          <div><FontAwesomeIcon icon={faBus} /> Bus</div>
          <div><FontAwesomeIcon icon={faTruck} /> Truck</div>
          <div><FontAwesomeIcon icon={faWater} /> Water Tanker</div>
        </div>
      </section>

      <section className="registration-services">
        <h2>Car Registration Services</h2>
        <ul className="services-grid">
          <li><FontAwesomeIcon icon={faTrafficLight} /> Open Traffic File</li>
          <li><FontAwesomeIcon icon={faRegistered} /> Car Registration</li>
          <li><FontAwesomeIcon icon={faSortNumericAsc} /> Number Plate Ownership</li>
          <li><FontAwesomeIcon icon={faMoneyBillTransfer} /> Transfer Vehicle</li>
          <li><FontAwesomeIcon icon={faDriversLicense} /> Issue Driving License</li>
          <li><FontAwesomeIcon icon={faRegistered} /> Company Vehicle Registration</li>
          <li><FontAwesomeIcon icon={faBalanceScale} /> Black Point Registration</li>
          <li><FontAwesomeIcon icon={faRemove} /> Impound Vehicle Removed</li>
          <li><FontAwesomeIcon icon={faRubleSign} /> Salik Registration</li>
        </ul>
      </section>

      <section className="registration-services">
        <h2 id="extend">Car Extension Services</h2>
        <ul className="services-grid">
          <li><FontAwesomeIcon icon={faRedo} /> Mulkiya Renewal</li>
          <li><FontAwesomeIcon icon={faDriversLicense} /> Driving License Renewal</li>
          <li><FontAwesomeIcon icon={faTeletype} /> Lajna Typing</li>
          <li><FontAwesomeIcon icon={faMoneyBill} /> All Type Fine Payments</li>
          <li><FontAwesomeIcon icon={faCircleUser} /> Reserve Number Plate</li>
          <li><FontAwesomeIcon icon={faCar} /> Transfer Car in Emirates</li>
          <li><FontAwesomeIcon icon={faTowerCell} /> Drab Toll Gate</li>
        </ul>
      </section>
    </div>
  );
}
