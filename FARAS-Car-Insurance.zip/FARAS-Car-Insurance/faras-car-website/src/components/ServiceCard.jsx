import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "../styles/components/serviceCard.scss";
import AOS from "aos";
import { useEffect } from "react";


function ServiceCard({ icon, heading, text }) {

    useEffect(() => {
        AOS.init({ duration: 1000 });
        }, []);

  return (
    <div className="service-card" data-aos="fade-right">
      <FontAwesomeIcon icon={icon} className="service-icon" />
      <h3>{heading}</h3>
      <p>{text}</p>
    </div>
  );
}

export default ServiceCard;
