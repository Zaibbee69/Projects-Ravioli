// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion"
import { faWhatsapp } from "@fortawesome/free-brands-svg-icons"
import { faEnvelope } from "@fortawesome/free-solid-svg-icons"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import "../styles/pages/quote.scss"

function QuoteBody()
{
    return(

        <>
            <div className="page-container">
                <motion.div className="quotes-hero"
                    initial={{ opacity: 0, y: 40 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, ease: "easeOut" }}>
                    
                    <h1>Get a Free <span>Quotation</span></h1>
                    <p>Send us your document details over at our Whatsapp or Email</p>
                    <p id="p-alt">You may be eligible for a Discount on documents verification basis!</p>
                    
                </motion.div>
            </div>

            <div className="quotes-detail">
                <div className="quotes-whatsapp" >
                    <h1>WhatsApp</h1>
                    <FontAwesomeIcon icon={faWhatsapp} />
                    
                    <p>
                    <strong>Contact 1:</strong>
                    <a
                        href="https://wa.me/971502331693"
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{color: "white"}}
                    >
                        050 2331 693
                    </a>
                    </p>

                    <p>
                    <strong>Contact 2:</strong>
                    <a
                        href="https://wa.me/971501410826"
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{color: "white"}}
                    >
                        050 1410 826
                    </a>
                    </p>
                </div>

                <div className="quotes-email">
                    <h1>Email</h1>
                    <FontAwesomeIcon icon={faEnvelope} />
                    
                    <p>
                    <a
                        href="mailto:farascarreg@gmail.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{color: "white"}}
                    >
                        farascarreg@gmail.com
                    </a>
                    </p>
                </div>
            </div>

        </>

    )
}

export default QuoteBody