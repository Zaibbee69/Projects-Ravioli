import "../styles/components/stats.scss"

function StatsBlock() {
  return (
    <section className="stats-section">
      <div className="stat-card" data-aos="fade-up">
        <h3>500+</h3>
        <p>Happy Clients</p>
      </div>
      <div className="stat-card" data-aos="fade-up" data-aos-delay="100">
        <h3>99%</h3>
        <p>Claim Approval Rate</p>
      </div>
      <div className="stat-card" data-aos="fade-up" data-aos-delay="200">
        <h3>5+</h3>
        <p>Years of Experience</p>
      </div>
      <div className="stat-card" data-aos="fade-up" data-aos-delay="300">
        <h3>1000+</h3>
        <p>Registrations Completed</p>
      </div>
    </section>
  )
}

export default StatsBlock
