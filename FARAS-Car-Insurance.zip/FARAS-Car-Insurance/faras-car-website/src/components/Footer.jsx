import "../styles/components/footer.scss"
import { Link } from "react-router-dom"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faPhone, faEnvelope, faLocationDot } from "@fortawesome/free-solid-svg-icons"
import { faWhatsapp } from "@fortawesome/free-brands-svg-icons"
import logo from "../assets/alt-logo.webp"
import banner from "../assets/banner.webp"

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-grid">
        {/* Column 1: Logo */}
        <div className="footer-col brand">
          <img src={logo} alt="FARAS Logo" />       
          <h2>Faras Car Insurance & Registration Services</h2>
          <p>Your trusted partner in car insurance & registration across UAE.</p>
          <img id="banner" src={banner} alt="Faras Banner" />
        </div>

        {/* Column 2: Pages */}
        <div className="footer-col">
          <h3>Pages</h3>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/services">Services</Link></li>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/contact">Contact</Link></li>
            <li><Link to="/quote">Get a Quote</Link></li>
          </ul>
        </div>

        {/* Column 3: Services */}
        <div className="footer-col">
          <h3>Services</h3>
          <ul>
            <li>Full Insurance</li>
            <li>Third-Party Insurance</li>
            <li>Registration Renewal</li>
            <li>Company Fleet Services</li>
            <li>Car Inspection & Extension</li>
          </ul>
        </div>

        {/* Column 4: Contact Info */}
        <div className="footer-col">
          <h3>Contact Us</h3>
          <ul>
            <li><FontAwesomeIcon icon={faPhone} /><strong>Contact 1:</strong> 0501410826</li>
            <li><FontAwesomeIcon icon={faPhone} /><strong>Contact 2:</strong> 0506746572</li>
            <li><FontAwesomeIcon icon={faWhatsapp} />+971 50 671 4578</li>
            <li><FontAwesomeIcon icon={faEnvelope} /> farascarreg@gmail.com</li>
            <li><FontAwesomeIcon icon={faLocationDot} /> Ajman, UAE</li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© 2025 FARAS. All rights reserved.</p>
      </div>
    </footer>
  )
}

export default Footer
