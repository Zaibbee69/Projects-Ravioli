import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

function HeroCard(props) {
    return (
        <div className="hero-card">
            <FontAwesomeIcon icon={props.icon} className="hero-icon" />
            <div className="hero-text">
                <h1>{props.heading}</h1>
                <p>{props.text}</p>
            </div>
        </div>
    );
}

export default HeroCard;
