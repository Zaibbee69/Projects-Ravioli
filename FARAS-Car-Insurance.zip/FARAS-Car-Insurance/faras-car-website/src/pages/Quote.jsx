import Navbar from "../components/Navbar"
import Footer from "../components/Footer"
import QuoteBody from "../components/QuoteBody"
import { Helmet } from "react-helmet-async"

function Quote() {
  return (
    <>
      <Helmet>
        <title>Get a Quote | FARAS Car Insurance UAE</title>
        <meta
          name="description"
          content="Get a quick and competitive quote for car insurance, registration, or renewal services from FARAS Car Insurance UAE. Fast processing & expert support."
        />
        <meta
          name="keywords"
          content="car insurance quote UAE, get a quote FARAS, car registration quote, UAE vehicle insurance price"
        />
        <meta property="og:title" content="Get a Quote | FARAS Car Insurance UAE" />
        <meta
          property="og:description"
          content="Fill out the form and receive a quote for car insurance or registration with FARAS Car Insurance in the UAE."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://farascarinsuranceandservices.netlify.app/quote" />
      </Helmet>

      <Navbar />
      <QuoteBody />
      <Footer />
    </>
  )
}

export default Quote
