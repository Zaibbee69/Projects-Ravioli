import { Helmet } from "react-helmet";
import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import TestimonialsSection from "../components/Testimonials";
import StatsBlock from "../components/StatBlock";
import PlugIn from "../components/PlugIn";
import Footer from "../components/Footer";
import "../styles/pages/main.scss";
import 'aos/dist/aos.css';
import ScrollMarquee from "../components/ScrollMarquee";
import "../styles/components/marquee.scss";

function MainPage() {
    const marquee = [
        "Open Traffic File", "Mulkiya Renewal", "Car Registration", 
        "Number Plate Ownership", "Transfer Vehicle", "Driving License Renewal",
        "Issue Driving License", "Lajna Typing", "Company Vehicle Registration",
        "Black Point Registration", "Impound Vehicle Removed", "All Type Fine Payments",
        "Reserve Number Plate", "Transfer Car in Emirates", "Drab Toll Gate", "Salik Registration"
    ];

    return (
        <>
            <Helmet>
                <title>FARAS Car Insurance & Registration Services | UAE</title>
                <meta name="description" content="Trusted car insurance, registration & renewal services in UAE. Quick, reliable, and hassle-free processing for individuals & businesses." />
                <meta name="keywords" content="Car insurance UAE, vehicle registration Dubai, FARAS car services, mulkiya renewal, driving license renewal, transfer vehicle, traffic file" />
                <meta name="author" content="FARAS Car Services" />

                {/* Open Graph for Facebook & LinkedIn */}
                <meta property="og:title" content="FARAS Car Insurance & Registration Services" />
                <meta property="og:description" content="All-in-one car services in the UAE. Insurance, registration, fine payments & more!" />
                <meta property="og:type" content="website" />
                <meta property="og:url" content="https://farascarinsuranceandservices.netlify.app" />
                {/* <meta property="og:image" content="https://your-image-url.com/og-image.jpg" /> */}

                {/* Twitter Card */}
                <meta name="twitter:card" content="summary_large_image" />
                <meta name="twitter:title" content="FARAS Car Insurance & Registration Services" />
                <meta name="twitter:description" content="All car-related services in UAE: Registration, license renewal, insurance & more!" />
                {/* <meta name="twitter:image" content="https://your-image-url.com/twitter-image.jpg" /> */}
            </Helmet>

            <Navbar />
            <Hero />
            <PlugIn />
            <StatsBlock />
            <ScrollMarquee marquee={marquee} />
            <TestimonialsSection />
            <Footer />
        </>
    );
}

export default MainPage;
