import Navbar from "../components/Navbar"
import Footer from "../components/Footer"
import AboutBody from "../components/AboutBody"
import { Helmet } from "react-helmet-async"

function About() {
  return (
    <>
      <Helmet>
        <title>About FARAS Car Insurance - UAE's Trusted Registration & Insurance Partner</title>
        <meta
          name="description"
          content="Learn more about FARAS Car Insurance - offering vehicle registration, license renewals, TPL & full insurance services across UAE with 100% trust and speed."
        />
        <meta
          name="keywords"
          content="FARAS, car insurance UAE, registration services, driving license renewal, TPL insurance, UAE vehicle services"
        />
        <meta property="og:title" content="About FARAS Car Insurance - UAE Vehicle Experts" />
        <meta property="og:description" content="Trusted partner in UAE for insurance, registration, and more." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://farascarinsuranceandservices.netlify.app/about" />
      </Helmet>

      <Navbar />
      <AboutBody />
      <Footer />
    </>
  )
}

export default About
