import "../styles/pages/contact.scss"
import Navbar from "../components/Navbar"
import Footer from "../components/Footer"
import ContactBody from "../components/ContactBody"
import { Helmet } from "react-helmet-async"

function ContactPage() {
  return (
    <>
      <Helmet>
        <title>Contact FARAS Car Insurance | UAE Car Registration & Insurance Help</title>
        <meta
          name="description"
          content="Need help with car insurance or registration? Contact FARAS Car Insurance for fast and reliable support across the UAE."
        />
        <meta
          name="keywords"
          content="FARAS contact, car insurance help UAE, registration support, insurance phone number, contact FARAS"
        />
        <meta property="og:title" content="Contact FARAS Car Insurance | Fast Support Across UAE" />
        <meta property="og:description" content="Reach out to FARAS for reliable car registration and insurance services." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://farascarinsuranceandservices.netlify.app/contact" />
      </Helmet>

      <Navbar />
      <ContactBody />
      <Footer />
    </>
  )
}

export default ContactPage
