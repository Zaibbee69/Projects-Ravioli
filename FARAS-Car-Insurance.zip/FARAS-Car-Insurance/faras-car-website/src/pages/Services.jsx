import Navbar from "../components/Navbar"
import Footer from "../components/Footer"
import ServicesBody from "../components/ServiceBody"
import { Helmet } from "react-helmet-async"

function Services() {
  return (
    <>
      <Helmet>
        <title>Our Services | FARAS Car Insurance UAE</title>
        <meta
          name="description"
          content="Explore FARAS Car Insurance services including car registration, insurance renewal, number plate transfer, fine payments, and more across the UAE."
        />
        <meta
          name="keywords"
          content="car insurance UAE, car registration UAE, vehicle renewal, number plate UAE, FARAS services, pay fines, UAE vehicle services"
        />
        <meta property="og:title" content="Our Services | FARAS Car Insurance UAE" />
        <meta
          property="og:description"
          content="Check out all services offered by FARAS Car Insurance — registration, renewal, TPL & full insurance, transfer of ownership, and more."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://farascarinsuranceandservices.netlify.app/services" />
      </Helmet>

      <Navbar />
      <ServicesBody />
      <Footer />
    </>
  )
}

export default Services
