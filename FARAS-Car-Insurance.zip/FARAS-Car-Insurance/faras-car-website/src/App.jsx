import { Routes, Route } from "react-router-dom"
import MainPage from "./pages/MainPage"
import About from "./pages/About"
import Services from "./pages/Services"
import Contact from "./pages/Contact"
import Quote from "./pages/Quote"
import ScrollToTop from "./components/ScrollToTop"
import WhatsAppFloatingButton from "./components/WhatsAppFloatingButton"

function App()
{
  return(
    <>
      <ScrollToTop />
      <Routes> 
        <Route path="/" element={<MainPage />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/quote" element={<Quote />} />           
      </Routes>
      <WhatsAppFloatingButton />
    </>
  )
}

export default App